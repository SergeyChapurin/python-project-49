### Hexlet tests and linter status:
[![Actions Status](https://github.com/SergeyChapurin/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/SergeyChapurin/python-project-49/actions)
<a href="https://codeclimate.com/github/SergeyChapurin/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4b41b0326b57dcc460c3/maintainability" /></a>
https://asciinema.org/a/4Lmu0nXnmuegiLD90lAh05Zhs
https://asciinema.org/a/Chpt8QAeHknpyu4XTm6fqlCyz
